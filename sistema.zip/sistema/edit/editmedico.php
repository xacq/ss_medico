<?php
    require_once("../config/verificacion.php");
  require_once("../config/link.php");

  if(isset($_POST['editarmedico'])){
    $id = $_GET['id'];

    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $cedula= $_POST['cedula'];
    $pasaporte= $_POST['pasaporte'];
    $telefono = $_POST['telefono'];
    $celular = $_POST['celular'];
    $direccion = $_POST['direccion'];
    $ciudad = $_POST['ciudad'];
    $nace = $_POST['nace'];
    $genero = $_POST['genero'];
    $depar = $_POST['depar'];
    $espe = $_POST['espe'];


    if ($cedula == "0"){
      echo '<script>alert("CEDULA MAL INGRESADA.  POR FAVOR INGRESE UNA CEDULA CORRECTA.")</script>';
      $cedula=="";
    }
    else{

      $sql = "UPDATE ssm_doctor SET 
      doctorcedula = '$cedula',
      doctornombres='$nombre',
      doctorcorreo = '$correo',
      doctordireccion = '$direccion',
      doctornace = '$nace',
      doctortelefono = '$telefono',
      doctorcelular = '$celular',
      doctordepartamento = '$depar',
      doctorespecialidad = '$espe',
      doctorciudad = '$ciudad',
      doctorpasport = '$pasaporte',
      doctorsexo = '$genero'
      WHERE doctoruser = '$id'";

      $result = mysqli_query($conectar, $sql);
          if($result){
              echo '<script>alert("FELICIDADES...! \nMEDICO EDITADO CORRECTAMENTE.")</script>';
              unset($_POST['crearuser']);
              $mostrar=0;
              echo '<script>window.location="../menu.php"</script>';
          }
          else{
              echo '<script>alert("OOPS...! \nERROR AL EDITAR MEDICO.")</script>';
              unset($_POST['crearuser']);
              $mostrar=0;
              echo '<script>window.location="../menu.php"</script>';
          }

        }
      }
      else{
      $id = $_SESSION['login_id'];
      $mostrar=1;
      $query = "SELECT * FROM ssm_doctor WHERE doctoruser = $id";
      $busqueda = mysqli_query($conectar, $query);
      $row_age = mysqli_fetch_array($busqueda);
      }
  require_once("./templates/headpac.php");
  require_once("../templates/info.php");
?>
    <section class="container">
      <form class="form login" action="./editmedico.php?id=<?php echo $id?>" method="POST">
        <div class="form_container"> 
        
          <h4 class="form_title center colver">Editar Medico</h4>

          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">people</i>
              <?php
                  if ($mostrar == 1){
                      echo '<input id="nombre" type="text" class="validate" required name="nombre" value="'.$row_age['doctornombres'].'">';
                  }
                  else{
                      echo '<input id="nombre" type="text" class="validate" required name="nombre">';
                  }
                ?>
              <label class="active" for="nombre">Nombres Completos</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">alternate_email</i>
              <?php
                  if ($mostrar == 1){
                      echo '<input id="last_name" type="text" class="validate" required  name=correo value="'.$row_age['doctorcorreo'].'">';
                  }
                  else{
                      echo '<input id="last_name" type="text" class="validate" required  name=correo>';
                  }
                ?>
              <label class="active" for="last_name">Correo</label>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">fingerprint</i>
              <?php
                if ($mostrar == 1){
                    echo ' <input id="cedula" type="text" class="validate" name="cedula" minlenght="10" maxlength="10" onkeypress="return valideKey(event);" value="'.$row_age['doctorcedula'].'">';
                }
                else{
                    echo ' <input id="cedula" type="text" class="validate" name="cedula" minlenght="10" maxlength="10" onkeypress="return valideKey(event);">';
                }
              ?>
              <label class="active" for="cedula">I D</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">style</i>
              <?php
                if ($mostrar == 1){
                    echo '<input id="pasaporte" type="text" class="validate" name="pasaporte" value="'.$row_age['doctorpasport'].'">';
                }
                else{
                    echo ' <input id="pasaporte" type="text" class="validate" name="pasaporte">';
                }
              ?>
              <label class="active" for="pasaporte">Pasaporte</label>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">phone</i>
              <?php
                if ($mostrar == 1){
                    echo '<input id="telefono" type="text" class="validate" required name="telefono" onkeypress="return valideKey(event);" value="'.$row_age['doctortelefono'].'">';
                }
                else{
                    echo '<input id="telefono" type="text" class="validate" required name="telefono" onkeypress="return valideKey(event);">';
                }
              ?>
              <label class="active" for="telefono">Telefono</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">phone_android</i>
              <?php
                if ($mostrar == 1){
                    echo '<input id="celular" type="text" class="validate" required  name=celular onkeypress="return valideKey(event);" onkeypress="return valideKey(event);" value="'.$row_age['doctorcelular'].'">';
                }
                else{
                    echo '<input id="celular" type="text" class="validate" required  name=celular onkeypress="return valideKey(event);">';
                }
              ?>
              <label class="active" for="celular">Celular</label>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">home</i>
              <?php
                if ($mostrar == 1){
                    echo '<input id="direccion" type="text" class="validate" required  name="direccion" value="'.$row_age['doctordireccion'].'">';
                }
                else{
                    echo '<input id="direccion" type="text" class="validate" required  name="direccion">';
                }
              ?>
              <label class="active" for="direccion">Direccion</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">business</i>
              <?php
                if ($mostrar == 1){
                    echo '<input id="ciudad" type="text" class="validate" required  name="ciudad" value="'.$row_age['doctorciudad'].'">';
                }
                else{
                    echo '<input id="ciudad" type="text" class="validate" required  name="ciudad">';
                }
              ?>
              <label class="active" for="ciudad">Ciudad</label>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">wc</i>
                <select id="genero" required  name=genero>
                <?php
                      if ($mostrar == 1){
                        echo '<option value="'.$row_age['doctorsexo'].'" selected="true">'.$row_age['doctorsexo'].'</option>';
                    }
                    else{
                        echo '<option value="">Seleccione una opción</option>';
                    }
                    $consulta="SELECT * FROM ssm_sexo";  
                    $resultado = mysqli_query($conectar, $consulta);
                    while ($row = mysqli_fetch_array($resultado)) {
                      echo '<option value="'.$row['sexoid'].'">'.$row['sexoid']." - ".$row['sexodescripcion'].'</option>';
                    }
                  ?>
                  </select>
              <label>Sexo</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">date_range</i>
              <?php
                if ($mostrar == 1){
                    echo '<input id="nace" type="text" class="datepicker" required  name="nace" value="'.$row_age['doctornace'].'">';
                }
                else{
                    echo '<input id="nace" type="text" class="datepicker" required  name="nace">';
                }
              ?>
              <label class="active" for="nace">Fecha de nacimiento</label>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">list</i>
              <select id="depar" required  name="depar">
              <?php
                    if ($mostrar == 1){
                      echo '<option value="'.$row_age['doctordepartamento'].'" selected="true">'.$row_age['doctordepartamento'].'</option>';
                      }
                    else{
                      echo '<option value="">Seleccione el departamanto del empleado</option>';
                      }
                    $consulta="SELECT * FROM ssm_departamento";  
                    $resultado = mysqli_query($conectar, $consulta);
                    while ($row = mysqli_fetch_array($resultado)) {
                      echo '<option value="'.$row['departamentoid'].'">'.$row['departamentoid']." - ".$row['departamentodescripcion'].'</option>';
                    }
                  ?>
              </select>
              <label>Departamento del empleado</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">list</i>
              <select id="espe" required  name="espe">
              <?php
                    if ($mostrar == 1){
                      echo '<option value="'.$row_age['doctorespecialidad'].'" selected="true">'.$row_age['doctorespecialidad'].'</option>';
                      }
                    else{
                      echo '<option value="">Seleccione el departamanto del empleado</option>';
                      }
                    $consulta="SELECT * FROM ssm_especialidad";  
                    $resultado = mysqli_query($conectar, $consulta);
                    while ($row = mysqli_fetch_array($resultado)) {
                      echo '<option value="'.$row['especialidadid'].'">'.$row['especialidadid']." - ".$row['especialidaddescripcion'].'</option>';
                    }
                  ?>
              </select>
              <label>Especialidad del empleado</label>
            </div>
          </div>

          <div class="row center">
            <button class="btn waves-effect waves-light grey darken-3" 
              type="submit" name="editarmedico">Actualizar
              <i class="material-icons right">update</i></button>
          </div>

        </div>
      </form>
    </section>                     

  </main>

<?php 
require_once("./templates/foot.php");
?>