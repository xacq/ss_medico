<?php
    require_once("../config/verificacion.php");
  require_once("../config/link.php");

  if(isset($_POST['editpaciente'])){
    $id = $_GET['id'];
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $cedula= $_POST['cedula'];
    $pasaporte= $_POST['pasaporte'];
    $telefono = $_POST['telefono'];
    $celular = $_POST['celular'];
    $direccion = $_POST['direccion'];
    $ciudad = $_POST['ciudad'];
    $nace = $_POST['fecha'];
    $genero = $_POST['genero'];

    if ($cedula == "0"){
      $cedula=="";
    }
    else{
      $sql = "UPDATE ssm_paciente SET 
      pacientenombres='$nombre',
      pacientecedula = '$cedula',
      pacientepasport = '$pasaporte',
      pacientenace = '$nace',
      pacientedireccion = '$direccion',
      pacientecorreo = '$correo',
      pacientetelefono = '$telefono',
      pacientecelular = '$celular',
      pacienteciudad = '$ciudad',
      pacientesexo = '$genero'
      WHERE pacienteuser = '$id'";

      $result = mysqli_query($conectar, $sql);
          if($result){
              echo '<script>alert("FELICIDADES...! \nPACIENTE EDITADO CORRECTAMENTE.")</script>';
              unset($_POST['crearuser']);
              $mostrar=0;
              echo '<script>window.location="../menu.php"</script>';
          }
          else{
              echo '<script>alert("OOPS...! \nERROR AL EDITAR PACIENTE.")</script>';
              unset($_POST['crearuser']);
              $mostrar=0;
              echo '<script>window.location="../menu.php"</script>';
          }
        }
      }
    else{
      $id = $_SESSION['login_id'];
      $mostrar=1;
      $query = "SELECT * FROM ssm_paciente WHERE pacienteuser = $id";
      $busqueda = mysqli_query($conectar, $query);
      $row_age = mysqli_fetch_array($busqueda);
      }    
  require_once("./templates/headpac.php");
  require_once("../templates/info.php");
?>
<section class="container ">
      <h4 class="form_title center colver">Nuevo Paciente</h4>
        <form class="col s12" action="./editpaciente.php?id=<?php echo $id?>" method="POST">
          <div class="form_container "> 

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">people</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="nombre" type="text" class="validate" name="nombre" value="'.$row_age['pacientenombres'].'" required >';
                    }
                    else{
                      echo '<input id="nombre" type="text" class="validate" name="nombre" required >';
                    }
                    ?>
                  <label class="active" for="nombre">Nombres Completos</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">alternate_email</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="correo" type="email" class="validate" name="correo" value="'.$row_age['pacientecorreo'].'" required >';
                    }
                    else{
                      echo '<input id="correo" type="email" class="validate" name="correo" required >';
                    }
                    ?>
                  <label class="active" for="last_name">Correo</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">fingerprint</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="cedula" type="text" class="validate" name="cedula" minlenght="10" maxlength="10" readonly value="'.$row_age['pacientecedula'].'">';
                    }?>
                  <label class="active" for="cedula">I D</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">style</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="pasaporte" type="text" class="validate" name="pasaporte" value="'.$row_age['pacientepasport'].'">';
                    }
                    else{
                      echo '<input id="pasaporte" type="text" class="validate" name="pasaporte">';
                    }
                    ?>
                  <label class="active" for="pasaporte">Pasaporte</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">phone</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="telefono" type="text" class="validate" name="telefono" value="'.$row_age['pacientetelefono'].'">';
                    }
                    else{
                      echo '<input id="telefono" type="text" class="validate" name="telefono">';
                    }
                    ?>
                  <label class="active" for="telefono">Telefono</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">phone_android</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="celular" type="text" class="validate" name="celular" onkeypress="return valideKey(event);" value="'.$row_age['pacientecelular'].'" required >';
                    }
                    else{
                      echo '<input id="celular" type="text" class="validate" name="celular" onkeypress="return valideKey(event);" required >';
                    }
                    ?>
                  <label class="active" for="celular">Celular</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">home</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="direccion" type="text" class="validate" name="direccion" value="'.$row_age['pacientedireccion'].'" required >';
                    }
                    else{
                      echo '<input id="direccion" type="text" class="validate" name="direccion" required >';
                    }
                    ?>
                  <label class="active" for="direccion">Direccion</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">business</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="ciudad" type="text" class="validate" name="ciudad" value="'.$row_age['pacienteciudad'].'" required >';
                    }
                    else{
                      echo '<input id="ciudad" type="text" class="validate" name="ciudad" required >';
                    }
                    ?>
                  <label class="active" for="ciudad">Ciudad</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">wc</i>
                    <select id="genero" name=genero required >
                      <?php
                        if ($mostrar == 1){
                          echo '<option value='.$row_age['pacientesexo'].'" selected>'.$row_age['pacientesexo'].'</option>';
                        }
                        else{
                          echo '<option value=" " selected>Seleccione Genero</option>';
                        }
                      ?>
                      <?php
                        $consulta="SELECT * FROM ssm_sexo";  
                        $resultado = mysqli_query($conectar, $consulta);
                        while ($row = mysqli_fetch_array($resultado)) {
                          echo '<option value='.$row['sexoid'].'">'.$row['sexoid']." - ".$row['sexodescripcion'].'</option>';
                        }
                      ?>
                      </select>
                  <label>Sexo</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">date_range</i>
                  <?php
                    if ($mostrar == 1){
                      echo '<input id="fecha" type="text" class="datepicker validate" name="fecha" value="'.$row_age['pacientenace'].'" required >';
                    }
                    else{
                      echo '<input id="fecha" type="text" class="datepicker validate" name="fecha" required >';
                    }
                    ?>
                  <label class="active" for="fecha">Fecha de nacimiento</label>
                </div>
              </div>

                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="editpaciente">Actualizar
                    <i class="material-icons right">update</i></button>
                </div>
          </form>
        </div>
      </div>
    </section>
    </main>
<?php
require_once("./templates/foot.php");
?>