<div class="container">
  <div class="progress"> <div class="determinate teal lighten-4" style="width: 100%"></div></div>
  <div class="progress"> <div class="determinate teal lighten-2" style="width: 100%"></div></div>
  <div class="progress"> <div class="determinate teal" style="width: 100%"></div></div>
</div>

<footer class="page-footer container">
    <div class="row center">
    <img src="../assets/img/logoemail.png" alt="" width="80px;">
      </div>
</footer>

    <!-- Vendor JS Files -->

    <script type="text/javascript" src="../../assets/js/materialize.js"></script>
    <script type="text/javascript" src="../../assets/js/main.js"></script>
    
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        M.AutoInit();
      });
    </script> 

    <script type="text/javascript">
      function valida_cedula() {
        var cad = document.getElementById("cedula").value.trim();
        var total = 0;
        var longitud = cad.length;
        var longcheck = longitud - 1;
        if (cad !== "" && longitud === 10){
          for(i = 0; i < longcheck; i++){
            if (i%2 === 0) {
              var aux = cad.charAt(i) * 2;
              if (aux > 9) aux -= 9;
              total += aux;
            } else {
              total += parseInt(cad.charAt(i)); // parseInt o concatenará en lugar de sumar
            }
          }
          total = total % 10 ? 10 - total % 10 : 0;
          if (cad.charAt(longitud-1) != total) {
            alert("CEDULA MAL INGRESADA.  POR FAVOR INGRESE UNA CEDULA CORRECTA.");
            document.getElementById("cedula").value = ("0");
          }
        }
      }
    </script>

  <script>    
    function valideKey(evt){
        var code = (evt.which) ? evt.which : evt.keyCode;    // code is the decimal ASCII representation of the pressed key.
        if(code==8) { // backspace.
          return true;
        } else if(code>=48 && code<=57) { // is a number.
          return true;
        } 
        else if (code==46){
          return true;
        }
        else{ // other keys.
          return false;
        }
      }
    </script>

<script>
      function calTotalTB(){
        var p1 = document.getElementById("p1").value;
        var p2 = document.getElementById("p2").value;
        var p3 = document.getElementById("p3").value;
        var p4 = document.getElementById("p4").value;
        var c1 = document.getElementById("c1").value;
        var c2 = document.getElementById("c2").value;
        var c3 = document.getElementById("c3").value;
        var c4 = document.getElementById("c4").value;
        var g1 = document.getElementById("g1").value;
        var g2 = document.getElementById("g2").value;
        var g3 = document.getElementById("g3").value;

        let res1 = parseFloat(p1) + parseFloat(p2)+parseFloat(p3)+parseFloat(p4)+parseFloat(c1) + parseFloat(c2)+parseFloat(c3)+parseFloat(c4)+parseFloat(g1) + parseFloat(g2)+parseFloat(g3);
        document.getElementById("tp").value = res1;

      }
    </script>

<script>
      function calTotalAH(){
        var p1 = document.getElementById("p5").value;
        var p2 = document.getElementById("p6").value;
        var p3 = document.getElementById("p7").value;
        var p4 = document.getElementById("p8").value;
        var c1 = document.getElementById("c5").value;
        var c2 = document.getElementById("c6").value;
        var c3 = document.getElementById("c7").value;
        var c4 = document.getElementById("c8").value;
        var g1 = document.getElementById("g4").value;
        var g2 = document.getElementById("g5").value;
        var g3 = document.getElementById("g6").value;

        let res1 = parseFloat(p1) + parseFloat(p2)+parseFloat(p3)+parseFloat(p4)+parseFloat(c1) + parseFloat(c2)+parseFloat(c3)+parseFloat(c4)+parseFloat(g1) + parseFloat(g2)+parseFloat(g3);
        document.getElementById("ah").value = res1;

      }
    </script>


<script>
      function calTotal(){
        var n1 = document.getElementById("numC").value;
        var n2 = document.getElementById("numP").value;
        var n3 = document.getElementById("numO").value;
        var n4 = document.getElementById("numec").value;
        var n5 = document.getElementById("numee").value;
        var n6 = document.getElementById("numoo").value;
        
        let res1 = parseFloat(n1) + parseFloat(n2)+parseFloat(n3);
        let res2 = parseFloat(n4) + parseFloat(n5)+parseFloat(n6);

        document.getElementById("CPO").value = res1;
        document.getElementById("ceo").value = res2;

      }
    </script>

<script>
      function calimc(){
        var n1 = document.getElementById("peso").value;
        var n2 = document.getElementById("estatura").value;
        let res1 = parseFloat(n1) / (parseFloat(n2)*parseFloat(n2));
        document.getElementById("imc").value =res1;
      }
    </script>

<script>
      function calpesoh(){
        var n1 = document.getElementById("estatura").value;
        let res1 = ((((parseFloat(n1)*100)-152.4)/2.54) * 2.27) + 45.4
        document.getElementById("ideal").value = res1;
      }
    </script>
  <script>
      function calpesom(){
        var n1 = document.getElementById("estatura").value;
        let res1 = ((((parseFloat(n1)*100)-152.4)/2.54) * 2.7) + 48.124
        document.getElementById("ideal").value = res1;
      }
    </script>

</body>
</html>