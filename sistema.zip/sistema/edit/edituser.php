<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");

    if(isset($_POST['editaruser'])){
      $id = $_GET['id'];

      $nombre = $_POST['nombre'];
      $email = $_POST['email'];

      $sql = "UPDATE ssm_user SET 
            usercorreo = '$email',
            username = '$nombre'
            WHERE id = $id";

      $result = mysqli_query($conectar, $sql);
            if($result){
                echo '<script>alert("FELICIDADES...! \nADMIN EDITADO CORRECTAMENTE.")</script>';
                unset($_POST['crearuser']);
                $mostrar=0;
                mysqli_close($conectar);
                echo '<script>window.location="../config/exit.php"</script>';
            }
            else{
                echo '<script>alert("OOPS...! \nERROR AL EDITAR ADMIN.")</script>';
                unset($_POST['crearuser']);
                $mostrar=0;
            }
        }
    elseif (isset($_GET['id'])){
      $id = $_GET['id'];
      $mostrar=1;
      $query = "SELECT * FROM ssm_user WHERE id = $id";
      $busqueda = mysqli_query($conectar, $query);
      $row_age = mysqli_fetch_array($busqueda);
      }
    require_once("./templates/head.php");
    require_once("../templates/info.php");
?>



<div class="container ">
        <form class="form login" action="./edituser.php?id=<?php echo $row_age['id'];?>" method="POST">
            <div class="form_container"> 
                <h4 class="form_title center colver">Editar Administrador</h4>

                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                  <i class="material-icons prefix">account_circle</i>
                  <?php
                    if ($mostrar == 1){
                        echo '<input type="text" class="validate" required name="nombre" value="'.$row_age['username'].'">';
                    }
                    else{
                        echo '<input type="text" required class="validate" name="nombre">';
                    }
                  ?>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE SU NOMBRE</span>
                  </div>
                </div>


                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                    <i class="material-icons prefix">alternate_email</i>
                    <?php
                        if ($mostrar == 1){
                            echo '<input type="email" class="validate" required name="email" value="'.$row_age['usercorreo'].'">';
                        }
                        else{
                            echo '<input type="email" required class="validate" name="email">';
                        }?>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE EL CORREO DEL USUARIO</span>
                  </div>
                </div>

            

                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="editaruser">Actualizar
                    <i class="material-icons right">update</i></button>
                </div>
                
            </div>
        </form>
    </main>


<?php 
require_once("./templates/foot.php");
?>