<!DOCTYPE html>
<?php
  require_once("./templates/head.php");
  require_once("./config/verificacion.php");
  require_once("./config/link.php");

?>
<title>ADMINISTRACION | SS. MEDICO</title>
</head>
<body>

<header id="header" class="fixed-top container">
      <div class=" d-flex align-items-center">
        <nav class="nav-extended">
          <div class="nav-wrapper">
          <a href="#" class="brand-logo"><img style="margin-top: -10px;" src="./assets/img/logo.png" alt="logo" width="70px"></a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger">
            <i class="material-icons">menu</i></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
              <li><a href="./lists/listpaciente.php">Pacientes</a></li>
              <li><a href="./lists/listmedico.php">Médicos</a></li>
              <li><a href="./lists/listturnoadmin.php">Turnos</a></li>
              <li><a href="./configuracion.php">Sistema</a></li>
              <li><a href="./menu.php"><i class="material-icons left">home</i>Inicio</a></li>
              <li><a href="./config/exit.php"><i class="material-icons left">exit_to_app</i>Salir</a></li>
            </ul>
          </div>
        </nav>
      </div>
      
      <ul class="sidenav" id="mobile-demo">
      <li><a href="./lists/listpaciente.php">Pacientes</a></li>
              <li><a href="./lists/listmedico.php">Médicos</a></li>
              <li><a href="./configuracion.php">Sistema</a></li>
              <li><a href="./menu.php"><i class="material-icons left">home</i>Inicio</a></li>
              <li><a href="./config/exit.php"><i class="material-icons left">exit_to_app</i>Salir</a></li>
      </ul>

</header>

<main>
<?php require_once("./templates/info.php"); ?>
  <div class="row">
    <div class="col m12 s12 center"> <img style="margin-top: -100px;" src="./assets/img/logogrande.png" alt="logo" width="200px"></div>
      <div class="col m12 s12 ">      <h4 class="form_title center colver">SISTEMA MEDICO</h4>  </div> 
      <div class="col m12 s12 ">      <h5 class="form_title center colver">ADMINISTRACION</h5>  </div>  
    </div>

    <div class="container"><div class="row center"><div class="form-container">
      <form action="./buscar/medico.php" method="POST">
        <div class="input-field col m8 s8"><i class="material-icons prefix">people</i>
          <input id="medico" type="text" class="validate" name="medico"><label for="medico">Buscar Medico</label>
        </div>
        <div class="input-field col m4 s4"><button class="btn waves-effect waves-light grey darken-3" type="submit" name="buscarmedico">Buscar
          <i class="material-icons right">search</i></button>
        </div>
      </form>
    

    
      <form action="./buscar/paciente.php" method="POST">
        <div class="input-field col m8 s8"><i class="material-icons prefix">people</i>
          <input id="paciente" type="text" class="validate" name="paciente"><label for="paciente">Buscar Paciente</label>
        </div>
        <div class="input-field col m4 s4"><button class="btn waves-effect waves-light grey darken-3" type="submit" name="buscarpaciente">Buscar
          <i class="material-icons right">search</i></button>
        </div>
      </form>
    </div>


  </div>
</main>
<?php
require_once("./templates/foot.php");
?>