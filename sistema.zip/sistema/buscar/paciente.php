<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    require_once("./templates/head.php");
    require_once("../templates/info.php");
?>
<?php
if (isset($_POST['buscarpaciente'])){
?>
    <div class="container">
        <div class="row">
            <div class="col m12 s12 ">
                <h4 class="form_title center colver">Pacientes encontrados</h4>
            </div>    
        </div>
        <table class="highlight centered responsive-table">
            <thead>
            <tr>
                <th>Acción</th>
                <th>Nombres</th>
                <th>Correo</th>
                <th>Celular</th>
                <th>Identificacion</th>

                <th>Fecha</th>
            </tr>
            </thead>

            <tbody>
            <?php
                $buscar_nombre = $_POST['paciente'];
                $query = "SELECT * FROM ssm_paciente WHERE pacientenombres LIKE '%$buscar_nombre%' ORDER BY pacientenombres asc";
                $resultado = mysqli_query($conectar, $query);
                if (mysqli_num_rows($resultado) >= 1){
                    while ($row = mysqli_fetch_array($resultado)){?>
                    <tr>
                        <td>
                            <a class="delete" href="../del/delpaciente.php?id=<?php echo $row['pacienteuser']?>" onclick="return confirmar('Esto eliminará no solo al paciente si no los turnos que pertenece y su historial clinico.\nEsta acción no se puede recuperar...!\n¿ESTA SEGURO QUE DESEA ELIMINAR ESTE REGISTRO?')">
                                <i class="material-icons tiny delete">delete_forever</i>BORRAR </a></td>
                        
                        <td><?php echo $row['pacientenombres']?></td>
                        <td><?php echo $row['pacientecorreo']?></td>
                        <td><?php echo $row['pacientecelular']?></td>
                        <td><?php echo $row['pacientecedula']?></td>
                        <td><?php echo $row['pacientecreado']?></td>

                    </tr>
                <?php  
                }}
                else{
                    echo '<script>alert("OOPS...!  \nNO SE ENCONTRARON RESULTADOS")</script>';
                    echo '<script>window.location="../3.medicogeneral.php"</script>';
                }?>
            </tbody>
        </table>
    </div>
</main>
<?php  } ?>
</main>
<?php     require_once("./templates/foot.php");  ?>