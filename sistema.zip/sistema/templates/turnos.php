 <!-- Modal Structure -->
 <div id="modalcalendario" class="modal  modal-fixed-footer">
    <div class="modal-content blue-grey lighten-4" id="calendar">
      <div class="row center">        
        
        <img src="../assets/img/logoemail.png" alt="" width="150px">
        <strong><H4 style="text-align:center; color:#045557">SISTEMA MEDICO</H4></strong>
        <H5 class="colver">TURNOS YA AGENDADOS</H5>
        <p class="colver">Le recordamos nuestro horario de atención de Lunes a Sabado desde las 8:00 a 19:00.</p>
        <div class="col s12">
          <table class=" highlight centered responsive">
            <thead>
            <tr>  
              <th>Fecha</th>
              <th>N. Turnos Asignados</th>
              <th>Horarios Agendados</th>
            </tr>  
            </thead>
            <tbody>
              <?php
              //Es mayor por que no queremos visualizar desde hoy
              $sql = "SELECT ssmtur_fecha, COUNT(`ssmtur_hora`) FROM `ssmturnos` WHERE ssmtur_fecha >= CURDATE() group BY ssmtur_fecha;";
              $resultado = mysqli_query($conectar, $sql);
              while ($row = mysqli_fetch_array($resultado)){
                $fecha = $row['ssmtur_fecha'];
                setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
                $dato = strftime("%d de %B de %Y", strtotime($fecha));
                $mensaje="";
                echo "<tr>";
                echo "<td>".saber_dia($row["ssmtur_fecha"]).", ".$dato."</td>";
                echo "<td>".$row["COUNT(`ssmtur_hora`)"]."</td>";
                $consulta="SELECT * FROM ssmturnos WHERE ssmtur_fecha = '".$row["ssmtur_fecha"]."' ORDER BY ssmtur_hora ASC";
                $res = mysqli_query($conectar, $consulta);
                  while ($row_age = mysqli_fetch_array($res)){
                    $mensaje .= $row_age["ssmtur_hora"]."<br>";    
                  }
                  echo "<td>".$mensaje."</td>";
                echo "</tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="modal-footer"> 
      <a href="#!" class="modal-close waves-effect waves-green btn-flat colver"><i class="large material-icons">exit_to_app</i></a>
    </div>
  </div>
    <!-- Modal Structure -->
