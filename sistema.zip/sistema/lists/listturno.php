<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    require_once("./templates/headmed.php");
    require_once("../templates/info.php");
?>

<div class="container">
    <div class="row">
        <div class="col m12 s12 ">
            <h4 class="form_title center colver">Lista de turnos</h4>
        </div>    
    </div>

  <table class="highlight centered responsive-table">
      <thead>
      <tr>
          <th>Nombre</th>
          <th>Fecha</th>
          <th>Hora</th>
      </tr>
      </thead>

      <tbody>
          <?php
            $id = $_SESSION['login_id'];
            $query = "SELECT * FROM ssm_turnos WHERE turnomedico = $id ORDER BY turnofecha DESC";
            $resultado = mysqli_query($conectar, $query);
            if ($resultado){
              while ($row = mysqli_fetch_array($resultado)) { ?>  
                <tr><td>
                    <?php 
                      $consulta="SELECT * FROM ssm_paciente WHERE pacienteuser = '".$row['turnopaciente']."'";
                      $resultado2 = mysqli_query($conectar, $consulta);
                      if ($resultado2){
                        while ($row2 = mysqli_fetch_array($resultado2)) {
                          echo $row2['pacientenombres'];
                          
                        }
                      }
                      ?></td>
                  <td><?php echo $row['turnofecha']?></td>
                  <td><?php echo $row['turnohora']?></td>
                </tr>
          <?php  
          }}
          ?>
      </tbody>
  </table>
</div>

</main>

<?php 
    require_once("./templates/foot.php");
?>
