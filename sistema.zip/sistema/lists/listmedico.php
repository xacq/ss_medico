<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    require_once("./templates/head.php");
    require_once("../templates/info.php");
?>

    <div class="container">
        <div class="row">
            <div class="col m12 s12 ">
                <h4 class="form_title center colver">Lista de Médicos</h4>
            </div>    
        <?php 
            if ($_SESSION['login_user']=="Administrador"){ ?>
                <div class="row center">
                <a href="../crear/crearmedico.php" class="waves-effect waves-light grey darken-3 btn-large"><i class="material-icons right">add</i>Nuevo</a>
            <?php } ?>        
        </div>

        <table class="highlight centered responsive-table">
            <thead>
            <tr>    
                <th>Acción</th>
                <th>Turnos</th>
                <th>Nombres</th>
                <th>Correo</th>
                <th>Celular</th>
                <th>Especialidad</th>
            </tr>
            </thead>

            <tbody>
            <?php

                $query = "SELECT * FROM ssm_doctor ORDER BY doctornombres asc";
                $resultado = mysqli_query($conectar, $query);
                while ($row = mysqli_fetch_array($resultado)){?>
                <tr>
                    <td>
                    <a class="delete" href="../del/delmedico.php?id=<?php echo $row['doctoruser']?>" onclick="return confirmar('¿Está seguro que desea eliminar el registro?')">
                        <i class="material-icons tiny delete">delete_forever</i>BORRAR </a></td>
                            
                    <td>
                        <a class="edit" href="./listturno.php?id=<?php echo $row['doctorid']?>">
                            <i class="material-icons tiny edit">edit</i>TURNOS</a></td>

                    
                    <td><?php echo $row['doctornombres']?></td>
                    <td><?php echo $row['doctorcorreo']?></td>
                    <td><?php echo $row['doctorcelular']?></td>
                    <td>
                        <?php
                            $query2 = "SELECT * FROM ssm_especialidad WHERE especialidadid = '".$row['doctorespecialidad']."'";
                            $resultado2 = mysqli_query($conectar, $query2);
                            while ($row2 = mysqli_fetch_array($resultado2)){
                                echo $row2['especialidaddescripcion'];
                            }
                        ?></td>
                </tr>
                <?php  
                }
                ?>
            </tbody>
        </table>
        </div>



    </main>
    
<?php 
    require_once("./templates/foot.php");
?>