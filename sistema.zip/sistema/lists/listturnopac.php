<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    require_once("./templates/headpac.php");
    require_once("../templates/info.php")
?>

<div class="container">
    <div class="row">
        <div class="col m12 s12 ">
            <h4 class="form_title center colver">Lista de turnos generados</h4>
        </div>    
    </div>

  <table class="highlight centered responsive-table">
      <thead>
      <tr>
          <th>Acción</th>
          <th>Fecha</th>
          <th>Hora</th>
          <th>Medico</th>
      </tr>
      </thead>

      <tbody>
          <?php
            $query = "SELECT * FROM ssm_turnos ORDER BY turnofecha DESC";
            $resultado = mysqli_query($conectar, $query);
            if ($resultado){
              while ($row = mysqli_fetch_array($resultado)) { ?>  
                <tr>
                  <td>
                    <a class="delete" href="../del/delturno.php?id=<?php echo $row['turnoid']?>" onclick="return confirmar('¿Está seguro que desea eliminar el registro?')">
                        <i class="material-icons tiny delete">delete_forever</i>BORRAR </a></td>
                  <td><?php echo $row['turnofecha']?></td>
                  <td><?php echo $row['turnohora']?></td>
                  <td><?php 
                      $consulta="SELECT * FROM ssm_doctor WHERE doctoruser = '".$row['turnomedico']."'";
                      $resultado2 = mysqli_query($conectar, $consulta);
                      if ($resultado2){
                        while ($row2 = mysqli_fetch_array($resultado2)) {
                          echo $row2['doctornombres'];
                        }
                      }
                      ?></td> 
                </tr>
          <?php  
          }}
          ?>
      </tbody>
  </table>
</div>

</main>

<?php 
    require_once("./templates/foot.php");
?>
