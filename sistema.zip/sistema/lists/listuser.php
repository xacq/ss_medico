<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    require_once("./templates/head.php");
    require_once("../templates/info.php");
?>

    <div class="container">
        <div class="row">
            <div class="col m12 s12 ">
                <h4 class="form_title center colver">Lista de Administradores</h4>
            </div>    
        </div>
        <div class="row center">
        <a href="../crear/crearuser.php" class="waves-effect waves-light grey darken-3 btn-large"><i class="material-icons right">add</i>Nuevo</a>
    </div>

        <table class="highlight centered responsive-table">
            <thead>
            <tr>
                <th>Acción</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Tipo de Usuario</th>
            </tr>
            </thead>

            <tbody>
            <?php
                $query = "SELECT * FROM ssm_user WHERE usertipo = 1 ORDER BY userfechacreado asc";
                $resultado = mysqli_query($conectar, $query);
                while ($row = mysqli_fetch_array($resultado)){?>
                <tr>
                    <td><a class="edit" href="../edit/edituser.php?id=<?php echo $row['id']?>" onclick="return confirmar('¿Está seguro que desea editar el registro?')">
                            <i class="material-icons tiny edit">edit</i>EDITAR</a></td>
                    
                    <td><?php echo $row['username']?></td>
                    <td><?php echo $row['usercorreo']?></td>
                    <td><?php
                        $consulta = "SELECT * FROM ssm_tipouser WHERE tipouserid = '".$row['usertipo']."'";
                        $resultado2 = mysqli_query($conectar, $consulta);
                        while ($row2 = mysqli_fetch_array($resultado2)){
                            echo $row2['tipouserdescripcion'];
                        }
                    ?>
                    </td>
                </tr>
                <?php  
                }
                ?>
            </tbody>
        </table>
        </div>



    </main>
    
<?php 
    require_once("./templates/foot.php");
?>