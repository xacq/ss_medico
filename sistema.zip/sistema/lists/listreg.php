<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    require_once("./templates/headx.php");
    require_once("../templates/info.php");
?>

    <div class="container">
        <div class="row">
            <div class="col m12 s12 ">
                <h4 class="form_title center colver">Lista de Ingresos General</h4>
            </div>    
        </div>

        <table class="highlight centered responsive-table">
            <thead>
            <tr>
                <th>Correo</th>
                <th>Fecha</th>
            </tr>
            </thead>

            <tbody>
            <?php
                $query = "SELECT * FROM ssm_registro ORDER BY registrodate asc";
                $resultado = mysqli_query($conectar, $query);
                while ($row = mysqli_fetch_array($resultado)){?>
                <tr>                    
                    <td><?php echo $row['registrocorreo']?></td>
                    <td><?php echo $row['registrodate']?></td>
                </tr>
                <?php  
                }
                ?>
            </tbody>
        </table>
        </div>
    </main>
<?php 
    require_once("./templates/foot.php");
?>