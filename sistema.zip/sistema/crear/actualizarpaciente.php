<?php
  require_once("../config/verificacion.php");
  require_once("../config/link.php");

  $correo = $_SESSION['login_correo'];

  if (isset($_POST['crearpaciente'])){
    $nombre = $_POST['nombre'];
    $cedula= $_POST['cedula'];
    $pasaporte= $_POST['pasaporte'];
    $telefono = $_POST['telefono'];
    $celular = $_POST['celular'];
    $direccion = $_POST['direccion'];
    $ciudad = $_POST['ciudad'];
    $nace = $_POST['nace'];
    $genero = $_POST['genero']; 

    if ($cedula == "0"){
      echo '<script>alert("CEDULA MAL INGRESADA.  POR FAVOR INGRESE UNA CEDULA CORRECTA.")</script>';
      $cedula=="";
    }
    else{
          $user = $_SESSION['login_id'];
          $consulta="INSERT INTO ssm_paciente(pacienteuser, pacientenombres, pacientecorreo, pacientecedula, pacientepasport, pacientetelefono, 
          pacientecelular, pacientedireccion, pacienteciudad, pacientesexo, pacientenace) 
            VALUES ('$user','$nombre','$correo','$cedula','$pasaporte','$telefono','$celular','$direccion','$ciudad','$genero','$nace')";
          $resultado = mysqli_query($conectar, $consulta);

          if ($resultado){
            $consulta="SELECT * FROM ssm_paciente WHERE pacientenombres = '$nombre' AND pacientecorreo = '$correo'";
            $resultado = mysqli_query($conectar, $consulta);
            $row = mysqli_fetch_array($resultado);
            $id = $row['pacienteuser'];

            $sql2="UPDATE ssm_user SET userestado = 1 WHERE id = '$id'"; 
            $resultado = mysqli_query($conectar, $sql2);

            echo '<script>window.alert("DATOS ACTUALIZADOS CORRECTAMENTE");</script>';
            echo '<script>window.location="../menu.php";</script>';
          }
          else
          {
            echo '<script>window.alert("DATOS NO SE HAN ACTUALIZADO");</script>';
            echo '<script>window.location="../menu.php";</script>';
          }
        }

  }
require_once("./templates/head.php");
require_once("../templates/info.php");
?>
    <section class="container ">
      <h4 class="form_title center colver">Actualizacion Datos del Paciente</h4>
        <form class="col s12" action="./actualizarpaciente.php" method="POST">
          <div class="form_container "> 
              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">people</i>
                  <input id="nombre" type="text" class="validate" required name="nombre">
                  <label class="active" for="nombre">Nombres Completos</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">alternate_email</i>
                  <input id="last_name" type="text" class="validate" required  name=correo disabled value="<?php echo $correo ?>">
                  <label class="active" for="last_name">Correo</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">fingerprint</i>
                  <input required id="cedula" type="text" class="validate"  name="cedula" minlenght="10" maxlength="10"  onkeypress="return valideKey(event);">
                  <label class="active" for="cedula">I D</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">style</i>
                  <input id="pasaporte" type="text" class="validate" name="pasaporte">
                  <label class="active" for="pasaporte">Pasaporte</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">phone</i>
                  <input id="telefono" type="text" class="validate" required name="telefono" onkeypress="return valideKey(event);">
                  <label class="active" for="telefono">Telefono</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">phone_android</i>
                  <input id="celular" type="text" class="validate" required  name=celular onkeypress="return valideKey(event);">
                  <label class="active" for="celular">Celular</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">home</i>
                  <input id="direccion" type="text" class="validate" required  name=direccion>
                  <label class="active" for="direccion">Direccion</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">business</i>
                  <input id="ciudad" type="text" class="validate" required  name=ciudad>
                  <label class="active" for="ciudad">Ciudad</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">wc</i>
                    <select id="genero" required  name=genero>
                      <option value="" disabled selected >Seleccione el género</option>
                      <?php
                        $consulta="SELECT * FROM ssm_sexo";  
                        $resultado = mysqli_query($conectar, $consulta);
                        while ($row = mysqli_fetch_array($resultado)) {
                          echo '<option value="'.$row['sexoid'].'">'.$row['sexodescripcion'].'</option>';
                        }
                      ?>
                      </select>
                  <label>Sexo</label>
                </div>
                <div class="input-field col m6 s12">
                  <i class="material-icons prefix">date_range</i>
                  <input id="nace" type="text" class="datepicker" required  name="nace">
                  <label class="active" for="nace">Fecha de nacimiento</label>
                </div>
              </div>

                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="crearpaciente">ACTUALIZAR DATOS
                    <i class="material-icons right">save</i></button>
                </div>
          </form>
        </div>
      </div>
    </section>
  </main>   

<?php
require_once("./templates/foot.php");
?>