<?php
  require_once("../config/verificacion.php");
  require_once("../config/link.php");

  if (isset($_POST['crearturno'])){
      $id = $_GET['id'];
      $fecha = $_POST['fecha'];
      $hora = $_POST['hora'];
      $medico = $_POST['medico'];

      $hoy = strtotime(date('Y-m-d',time()));
      $fec = strtotime($fecha);
      
      $consulta="SELECT * FROM ssm_turnos WHERE turnofecha = '$fecha' AND turnohora = '$hora'";
      $resultado = mysqli_query($conectar, $consulta);

      if (mysqli_num_rows($resultado) == 1 OR $fec <= $hoy){
        echo '<script>alert("LO SENTIMOS...!\nLA FECHA Y LA HORA ESCOGIDAS, YA ESTAN OCUPADAS O SON INCORRECTAS.\nPOR FAVOR ESCOJA UNA FECHA Y HORA DISTINTAS.")</script>';
      }
      else{
        $consulta="INSERT INTO ssm_turnos (turnopaciente, turnomedico, turnofecha, turnohora) 
        VALUES ('$id','$medico','$fecha', '$hora')";
        $result = mysqli_query($conectar, $consulta);
        if ($result){
          echo '<script>alert("FELICIDADES...!\n EL TURNO SE HA CREADO")</script>';
          echo '<script>window.location.href="../lists/listturnopac.php"</script>';
        
          $sql_est = "UPDATE ssmpacientes SET ssmpac_estado = '2' WHERE ssmpac_id = '$id'";
          $result_est = mysqli_query($conectar, $sql_est);
        }
        else{
          echo '<script>alert("ERROR AL CREAR EL TURNO")</script>';
          echo '<script>window.location.href="./crearturno.php"</script>';
        }
      }
    }

  $id =  $_SESSION['login_id'];
  require_once("./templates/headpac.php");
  require_once("../templates/info.php");
?>
    <section class="container">
      <div class="row center">
        <h4 class="form_title center colver">Nuevo Turno</h4>
        <p class="center colver">LLENE EL FORMULARIO PARA ASIGNAR UN PACIENTE CON UN ESPECIALISTA</p>
      </div>
        <form class="col s12" action="./crearturno.php?id=<?php echo $id?>" method="POST">
          <div class="form_container "> 
              
              <div class="row"> 
                <div class="input-field col m6 s12 offset-m3">
                  <i class="material-icons prefix">event</i>
                    <input id="fecha" class="datepicker" name=fecha  required>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE LA FECHA DE SU CITA</span>
                    <label class="active" for="nombre">Fecha de la cita</label>
                </div>
                <div class="input-field col m6 s12 offset-m3">
                  <i class="material-icons prefix">list</i>
                      <select name="hora" required>
                      <option value="" selected disabled>Seleccione una hora para su cita</option>
                      <?php
                          $consulta="SELECT * FROM smm_horas ORDER BY horasname ASC";
                          $resultado = mysqli_query($conectar, $consulta);
                          while ($row = mysqli_fetch_array($resultado)) {
                            echo '<option value="'.$row['horasname'].'">'.$row['horasname'].'</option>';
                          }
                      ?>
                      </select>
                      <label>Hora de su cita</label>
                      <span class="helper-text" data-error="wrong" data-success="right">INGRESE LA HORA PARA SU CITA</span>
                </div>

              </div>
            <div class="row">
              <div class="input-field col m6 s12 offset-m3">
                <i class="material-icons prefix">list</i>
                <select id="medico" required  name="medico">
                  <option value="" disabled selected >Seleccione el medico especialista</option>
                  <?php
                  $consulta="SELECT * FROM ssm_doctor";  
                  $resultado = mysqli_query($conectar, $consulta);
                  while ($row = mysqli_fetch_array($resultado)) {
                    $sql_esp = "SELECT * FROM ssm_especialidad WHERE especialidadid = ".$row['doctorespecialidad'];
                    $result_esp = mysqli_query($conectar, $sql_esp);
                    $row_esp = mysqli_fetch_array($result_esp);
                    echo '<option value="'.$row['doctoruser'].'">'.$row['doctornombres'].' - '.$row_esp['especialidaddescripcion'].'</option>';
                  }
                  ?>
                </select>
                <label>Lista de especialistas</label>
              </div>
            </div>
                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="crearturno">Crear
                    <i class="material-icons right">save</i></button>
                </div>
          </form>
        </div>
      </div>
    </section>
  </main>   
<?php
require_once("./templates/foot.php");
?>