<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    if(isset($_POST['creardepar'])){
        $depar = $_POST['depar'];

        $sql = "INSERT INTO ssm_departamento (departamentodescripcion) 
            VALUES ('$depar')";
        $result = mysqli_query($conectar, $sql);
            if($result){
                echo '<script>alert("FELICIDADES...! \nDEPARTAMENTO CREADO CORRECTAMENTE.")</script>';
                unset($_POST['creardepar']);
                echo '<script>window.location="../lists/listdepar.php"</script>';
            }
            else{
                echo '<script>alert("OOPS...! \nERROR AL CREAR EL DEPARTAMENTO.")</script>';
                unset($_POST['creardepar']);
                echo '<script>window.location="../lists/listdepar.php"</script>';
            }
        }
    
    require_once("./templates/headx.php");
    require_once("../templates/info.php");
?>

    <div class="container ">
        <form class="form login" action="./creardepar.php" method="POST">
            <div class="form_container"> 
                <h4 class="form_title center colver">Sección Departamentos</h4>
                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                  <i class="material-icons prefix">badge</i>
                    <input id="depar" name="depar" required type="text">
                    <label for="depar">Nombre del departamento</label>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE EL NUEVO DEPARTAMENTO</span>
                  </div>
                </div>

                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="creardepar">Crear
                    <i class="material-icons right">save</i></button>
                </div>
            </div>
        </form>
    </main>


<?php 
    require_once("./templates/foot.php");
?>