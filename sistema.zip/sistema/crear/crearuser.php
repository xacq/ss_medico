<?php
  require_once("../config/verificacion.php");
  require_once("../config/link.php");

    if(isset($_POST['crearuser'])){
        $nombre = $_POST['nombre'];
        $email = $_POST['email'];

        $sql = "INSERT INTO ssm_user (usercorreo,userpassword,username,usertipo) 
            VALUES ('$email','123','$nombre','1')";
        $result = mysqli_query($conectar, $sql);
            if($result){
                echo '<script>alert("FELICIDADES...! \nADMIN CREADO CORRECTAMENTE.")</script>';
                unset($_POST['crearuser']);
                echo '<script>window.location="../lists/listuser.php"</script>';
            }
            else{
                echo '<script>alert("OOPS...! \nERROR AL CREAR USUARIO ADMIN.")</script>';
                unset($_POST['crearuser']);
                echo '<script>window.location="../lists/listuser.php"</script>';
            }
        }

    require_once("./templates/head.php");
    require_once("../templates/info.php");
?>

    <div class="container ">
        <form class="form login" action="./crearuser.php" method="POST">
            <div class="form_container"> 
                <h4 class="form_title center colver">Sección Admin</h4>

                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                  <i class="material-icons prefix">account_circle</i>
                    <input type="text" id="nombre" name="nombre" required>
                    <label for="nombre">Nombres Completos</label>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE SU NOMBRE</span>
                  </div>
                </div>


                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                    <i class="material-icons prefix">alternate_email</i>
                    <input id="email" type="email" class="validate" required name="email">
                    <label for="email">Email</label>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE EL CORREO DEL USUARIO</span>
                  </div>
                </div>
                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="crearuser">Crear
                    <i class="material-icons right">save</i></button>
                </div>
            </div>
        </form>
        <br><P class="center colver">LUEGO DE CREAR UN USUARIO, LA CONTRASEÑA POR DEFECTO SERA 123. <p class="delete center">POR FAVOR CAMBIE LA MISMA.</p> </P>
    </main>


<?php 
require_once("./templates/foot.php");
?>