<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    if(isset($_POST['crearespe'])){
        $espe = $_POST['espe'];

        $sql = "INSERT INTO ssm_especialidad (especialidaddescripcion) 
            VALUES ('$espe')";
        $result = mysqli_query($conectar, $sql);
            if($result){
                echo '<script>alert("FELICIDADES...! \nESPECIALIDAD CREADA CORRECTAMENTE.")</script>';
                unset($_POST['crearespe']);
                echo '<script>window.location="../lists/listespe.php"</script>';
            }
            else{
                echo '<script>alert("OOPS...! \nERROR AL CREAR LA ESPECIALIDAD.")</script>';
                unset($_POST['crearespe']);
                echo '<script>window.location="../lists/listespe.php"</script>';
            }
        }
    
    require_once("./templates/headx.php");
    require_once("../templates/info.php");
?>

    <div class="container ">
        <form class="form login" action="./crearespe.php" method="POST">
            <div class="form_container"> 
                <h4 class="form_title center colver">Sección Especialidades</h4>

                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                  <i class="material-icons prefix">high_quality</i>
                    <input id="espe" name="espe" required type="text">
                    <label for="espe">Nombre de la especialidad</label>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE LA NUEVA ESPECIALIDAD</span>
                  </div>
                </div>

                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="crearespe">Crear
                    <i class="material-icons right">save</i></button>
                </div>
            </div>
        </form>
    </main>


<?php 
    require_once("./templates/foot.php");
?>