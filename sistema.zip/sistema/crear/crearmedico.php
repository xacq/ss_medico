<?php
  require_once("../config/verificacion.php");
  require_once("../config/link.php");
  require_once("./templates/head.php");
  require_once("../templates/info.php");

  if (isset($_POST['crearmedico'])){
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $cedula= $_POST['cedula'];
    $pasaporte= $_POST['pasaporte'];
    $telefono = $_POST['telefono'];
    $celular = $_POST['celular'];
    $direccion = $_POST['direccion'];
    $ciudad = $_POST['ciudad'];
    $nace = $_POST['nace'];
    $genero = $_POST['genero'];
    $depar = $_POST['depar'];
    $espe = $_POST['espe'];


    if ($cedula == "0"){
      echo '<script>alert("CEDULA MAL INGRESADA.  POR FAVOR INGRESE UNA CEDULA CORRECTA.")</script>';
      $cedula=="";
    }
    else{
      $consulta = "INSERT INTO ssm_doctor(doctoruser, doctornombres, doctorcorreo, doctorcedula, doctorpasport, doctortelefono, 
      doctorcelular, doctordireccion, doctorciudad, doctorsexo, doctornace, doctordepartamento, doctorespecialidad) 
      VALUES (0, '$nombre', '$correo', '$cedula', '$pasaporte', '$telefono', '$celular', '$direccion', '$ciudad', 
      '$genero', '$nace', '$depar', '$espe')";
      $resultado = mysqli_query($conectar, $consulta);

      $sql = "INSERT INTO ssm_user (usercorreo, userpassword, username, usertipo, userestado) 
              VALUES ('$correo', '123', '$nombre', 2, 1)";
      $result = mysqli_query($conectar, $sql);

      $selecciona = "SELECT * FROM ssm_user WHERE usercorreo = '$correo'"; 
      $res = mysqli_query($conectar, $selecciona);
      while ($row = mysqli_fetch_array($res)){
          $var = $row['id'];
      }

      $actualizacion = "UPDATE ssm_doctor SET doctoruser = $var WHERE doctorcorreo = '$correo'";
      $resulta = mysqli_query($conectar, $actualizacion);

      if ($resulta){

        echo '<script>window.alert("MEDICO GENERADO CORRECTAMENTE");</script>';
        echo '<script>window.location="../lists/listmedico.php";</script>';
      }
      else
      {
        echo '<script>window.alert("EL MEDICO NO SE HA GENERADO CORRECTAMENTE");</script>';
        echo '<script>window.location="../lists/listmedico.php";</script>';
      }
    }
  }

?>

    <main>  

    <section class="container ">
      <div class="form_container "> 
      <h4 class="form_title center colver">Nuevo Profesional</h4>
      <p class="center colver">LLENE LOS CAMPOS PARA CREAR UN NUEVO PROFESIONAL PARA LOS TRATAMIENTOS</p>
        <form class="col s12" action="./crearmedico.php" method="POST"> 
          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">people</i>
              <input id="nombre" type="text" class="validate" required name="nombre">
              <label class="active" for="nombre">Nombres Completos</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">alternate_email</i>
              <input id="last_name" type="text" class="validate" required  name=correo>
              <label class="active" for="last_name">Correo</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">fingerprint</i>
              <input id="cedula" type="text" class="validate"  name="cedula" minlenght="10" maxlength="10" onkeypress="return valideKey(event);">
              <label class="active" for="cedula">I D</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">style</i>
              <input id="pasaporte" type="text" class="validate" name="pasaporte">
              <label class="active" for="pasaporte">Pasaporte</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">phone</i>
              <input id="telefono" type="text" class="validate" required name="telefono" onkeypress="return valideKey(event);">
              <label class="active" for="telefono">Telefono</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">phone_android</i>
              <input id="celular" type="text" class="validate" required  name=celular onkeypress="return valideKey(event);">
              <label class="active" for="celular">Celular</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">home</i>
              <input id="direccion" type="text" class="validate" required  name=direccion>
              <label class="active" for="direccion">Direccion</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">business</i>
              <input id="ciudad" type="text" class="validate" required  name=ciudad>
              <label class="active" for="ciudad">Ciudad</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">wc</i>
                <select id="genero" required  name=genero>
                  <option value="" disabled selected >Seleccione el sexo</option>
                  <?php
                    $consulta="SELECT * FROM ssm_sexo";  
                    $resultado = mysqli_query($conectar, $consulta);
                    while ($row = mysqli_fetch_array($resultado)) {
                      echo '<option value="'.$row['sexoid'].'">'.$row['sexodescripcion'].'</option>';
                    }
                  ?>
                  </select>
              <label>Sexo</label>
            </div>
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">date_range</i>
              <input id="nace" type="text" class="datepicker" required  name="nace">
              <label class="active" for="nace">Fecha de nacimiento</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col m6 s12">
              <i class="material-icons prefix">list</i>
              <select id="depar" required  name="depar">
                <option value="" disabled selected >Seleccione el departamanto del profesional</option>
                <?php
                $consulta="SELECT * FROM ssm_departamento";  
                $resultado = mysqli_query($conectar, $consulta);
                while ($row = mysqli_fetch_array($resultado)) {
                  echo '<option value="'.$row['departamentoid'].'">'.$row['departamentodescripcion'].'</option>';
                }
                ?>
              </select>
              <label>Departamento del empleado</label>
            </div>

            <div class="input-field col m6 s12">
              <i class="material-icons prefix">list</i>
              <select id="espe" required  name="espe">
                <option value="" disabled selected >Seleccione el area del profesional</option>
                <?php
                $consulta="SELECT * FROM ssm_especialidad";  
                $resultado = mysqli_query($conectar, $consulta);
                while ($row = mysqli_fetch_array($resultado)) {
                  echo '<option value="'.$row['especialidadid'].'">'.$row['especialidaddescripcion'].'</option>';
                }
                ?>
              </select>
              <label>Especialidad del pofesional</label>
            </div> 
          </div>

            <div class="row center">
              <button class="btn waves-effect waves-light grey darken-3" 
                type="submit" name="crearmedico">Crear
                <i class="material-icons right">save</i></button>
            </div>
          </form>
        </div>
      </section>
    </main>   
    
<?php
include("./templates/foot.php");
?>