<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    if(isset($_POST['creargen'])){
        $gen = $_POST['gen'];

        $sql = "INSERT INTO ssm_sexo (sexodescripcion) 
            VALUES ('$gen')";
        $result = mysqli_query($conectar, $sql);
            if($result){
                echo '<script>alert("FELICIDADES...! \nSEXO CREADO CORRECTAMENTE.")</script>';
                unset($_POST['creargen']);
                echo '<script>window.location="../lists/listgen.php"</script>';
            }
            else{
                echo '<script>alert("OOPS...! \nERROR AL CREAR EL SEXO.")</script>';
                unset($_POST['creargen']);
                echo '<script>window.location="../lists/listgen.php"</script>';
            }
        }
    
    require_once("./templates/headx.php");
    require_once("../templates/info.php");
?>

    <div class="container ">
        <form class="form login" action="./creargen.php" method="POST">
            <div class="form_container"> 
                <h4 class="form_title center colver">Sección Sexo</h4>

                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                  <i class="material-icons prefix">wc</i>
                    <input id="gen" name="gen" required type="text">
                    <label for="gen">Nombre del sexo</label>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE El SEXO</span>
                  </div>
                </div>

                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="creargen">Crear
                    <i class="material-icons right">save</i></button>
                </div>
            </div>
        </form>
    </div> 
    
    </main>
<?php 
    require_once("./templates/foot.php");
?>