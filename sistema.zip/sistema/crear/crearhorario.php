<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    if(isset($_POST['crearhorario'])){
        $hora = $_POST['horario'];
        $sql = "INSERT INTO smm_horas (horasname) VALUES ('$hora')";
        $result = mysqli_query($conectar, $sql);
            if($result){
                echo '<script>alert("FELICIDADES...! \nHORARIO CREADO CORRECTAMENTE.")</script>';
                unset($_POST['crearhorario']);
                echo '<script>window.location="../lists/listhorario.php"</script>';
            }
            else{
                echo '<script>alert("OOPS...! \nERROR AL CREAR EL HORARIO.")</script>';
                unset($_POST['crearhorario']);
                echo '<script>window.location="../lists/listhorario.php"</script>';
            }
        }
    
    require_once("./templates/headx.php");
    require_once("../templates/info.php");
?>

    <div class="container ">
        <form class="form login" action="./crearhorario.php" method="POST">
            <div class="form_container"> 
                <h4 class="form_title center colver">Sección Horarios</h4>

                <div class="row">
                  <div class="input-field col m8 s10 offset-m2 offset-s2">
                  <i class="material-icons prefix">more_time</i>
                    <input id="horario" name="horario" class="timepicker" required>
                    <span class="helper-text" data-error="wrong" data-success="right">INGRESE LA HORA PARA NUEVO HORARIO</span>
                  </div>
                </div>

                <div class="row center">
                  <button class="btn waves-effect waves-light grey darken-3" 
                    type="submit" name="crearhorario">Crear
                    <i class="material-icons right">save</i></button>
                </div>
            </div>
        </form>
        <br><P class="center colver">PARA CREAR SU HORARIO DE ATENCION LE RECOMENDAMOS HACERLO MANTENIENDO <p class="delete center">EL ORDEN DE LAS HORAS.</p> </P>
    </main>


<?php 
    require_once("./templates/foot.php");
?>