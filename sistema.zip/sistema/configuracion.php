<!DOCTYPE html>
<?php
  require_once("./config/verificacion.php");
  date_default_timezone_set('America/Bogota');  
  require_once("./templates/head.php") ?>
  <title>CONFIGURACION | SS. MEDICO</title>
  </head>
<body>
  <header id="header" class="fixed-top container">
      <div class=" d-flex align-items-center">
        <nav class="nav-extended">
          <div class="nav-wrapper" style="background-color:#45582C">
          <a href="#" class="brand-logo"><img style="margin-top: -10px;" src="./assets/img/logo.png" alt="logo" width="70px"></a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
              <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a class="dropdown-trigger" href="#!" data-target="dropdown1" >Lista</a></li>
                <li><a class="dropdown-trigger" href="#!" data-target="dropdown3">Usuarios</a></li>
                <li><a href="./administracion.php"><i class="material-icons left">home</i>Regresar</a></li>
                <li><a  href="./config/exit.php"><i class="material-icons left">exit_to_app</i>Salir</a></li>
              </ul>
          </div>
                <ul id="dropdown1" class="dropdown-content">
                  <li><a href="./lists/listhorario.php">Horarios</a></li>
                  <li><a href="./lists/listdepar.php">Departamentos</a></li>
                  <li><a href="./lists/listespe.php">Especialidades</a></li>
                  <li><a href="./lists/listgen.php">Sexos</a></li>
                </ul>
                <ul id="dropdown3" class="dropdown-content">
                  <li><a href="./lists/listtipo.php">Tipos</a></li>
                  <li><a href="./lists/listuser.php">Lista</a></li>
                  <li><a href="./lists/listreg.php">Ingresos</a></li>
                </ul>
        </nav>
      </div>
    </header>

  <main>  
    
    <?php require_once("./templates/info.php"); ?>

    <div class="row">
    <div class="col m12 s12 center"> <img style="margin-top: -100px;" src="./assets/img/logogrande.png" alt="logo" width="200px"></div>
      <div class="col m12 s12 ">      <h4 class="form_title center colver">SISTEMA MEDICO</h4>  </div> 
      <div class="col m12 s12 ">      <h5 class="form_title center colver">CONFIGURACION DEL SISTEMA</h5>  </div>  
    </div>

  </main>

<?php
require_once("./templates/foot.php");
?>