<!DOCTYPE html>
<?php
  require_once("./templates/head.php");
  require_once("./config/verificacion.php");
  require_once("./config/link.php");

?>
<title>SISTEMA MEDICO</title>
</head>
<body>
  <main>
    <header id="header" class="fixed-top container">
      <div class=" d-flex align-items-center">
        <nav class="nav-extended">
          <div class="nav-wrapper">
          <a href="#" class="brand-logo"><img style="margin-top: -10px;" src="./assets/img/logo.png" alt="logo" width="70px"></a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger">
            <i class="material-icons">menu</i></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
              <?php if ($_SESSION['login_user']== "Administrador"){ ?>
              <li><a  href="./administracion.php"><i class="material-icons left">people</i>Administración</a></li> <?php }   ?>

              <?php if ($_SESSION['login_user']== "Paciente"){ ?>
              <li><a  href="./crear/crearturno.php"><i class="material-icons left">people</i>Nuevo Turno</a></li> 
              <li><a  href="./edit/editpaciente.php"><i class="material-icons left">people</i>Actualizar</a></li> <?php }   ?>

              <?php if ($_SESSION['login_user']== "Medico"){ ?>
                <li><a  href="./lists/listturno.php"><i class="material-icons left">people</i>Turnos</a></li> 
              <li><a  href="./edit/editmedico.php"><i class="material-icons left">people</i>Actualizar</a></li> <?php }   ?>

              <li><a href="./config/exit.php"> <i  class="material-icons left">exit_to_app</i>Salir</a></li>
            </ul>
          </div>
        </nav>
      </div>
      
      <ul class="sidenav" id="mobile-demo">
        <li class="center"><img src="./assets/img/logogrande.png" alt="LOGO" width="100px"></li>
        <?php 
        if ($_SESSION['login_user']=="Administrador"){ ?>
          <li><a href="./administracion.php">Administración</a></li>      <?php } ?>
        <li><a href="./config/exit.php"><i class="material-icons left">exit_to_app</i>Salir</a></li>
      </ul>
    </header>
  <?php require_once("./templates/info.php"); ?>
  <div class="row">
    <div class="col m12 s12 center"> <img style="margin-top: -100px;" src="./assets/img/logogrande.png" alt="logo" width="100px"></div>
    <div class="col m12 s12 ">     <h4 class="form_title center colver">SISTEMA MEDICO</h4>  </div> 
    <div class="col m12 s12 ">     <h5 class="form_title center colver">SOFTWARE DE GESTION INTERNA</h5>  </div>  
  </div>


<?php if ($_SESSION['login_user']=="Paciente"){ ?>
  <div class="container">
    <div class="row">
        <div class="col m12 s12 ">
            <h4 class="form_title center colver">Lista de turnos generados</h4>
        </div>    
    </div>

  <table class="highlight centered responsive-table">
      <thead>
      <tr>
          <th>Acción</th>
          <th>Fecha</th>
          <th>Hora</th>
          <th>Medico</th>
      </tr>
      </thead>

      <tbody>
          <?php
            $id = $_SESSION['login_id'];
            $query = "SELECT * FROM ssm_turnos WHERE turnopaciente = $id AND turnofecha > CURDATE() ORDER BY turnofecha DESC";
            $resultado = mysqli_query($conectar, $query);
            if ($resultado){
              while ($row = mysqli_fetch_array($resultado)) { ?>  
                <tr>
                  <td>
                    <a class="delete" href="../del/delturno.php?id=<?php echo $row['turnoid']?>" onclick="return confirmar('¿Está seguro que desea eliminar el registro?')">
                        <i class="material-icons tiny delete">delete_forever</i>BORRAR </a></td>

                  <td><?php echo $row['turnofecha']?></td>
                  <td><?php echo $row['turnohora']?></td>
                  <td><?php 
                      $consulta="SELECT * FROM ssm_doctor WHERE doctoruser = '".$row['turnomedico']."'";
                      $resultado2 = mysqli_query($conectar, $consulta);
                      if ($resultado2){
                        while ($row2 = mysqli_fetch_array($resultado2)) {
                          echo $row2['doctornombres'];
                        }
                      }
                      ?></td> 
                </tr>
          <?php  
          }}
          ?>
      </tbody>
  </table>
</div>
<?php }?>


<?php if ($_SESSION['login_user']=="Administrador"){ ?>
  <div class="container">
    <div class="row">
        <div class="col m12 s12 ">
            <h4 class="form_title center colver">Lista de turnos para hoy</h4>
        </div>    
    </div>

  <table class="highlight centered responsive-table">
      <thead>
      <tr>
          <th>Acción</th>
          <th>Fecha</th>
          <th>Hora</th>
          <th>Medico</th>
          <th>Paciente</th>
      </tr>
      </thead>

      <tbody>
          <?php
            $query = "SELECT * FROM ssm_turnos WHERE turnofecha = CURDATE() ORDER BY turnofecha DESC";
            $resultado = mysqli_query($conectar, $query);
            if ($resultado){
              while ($row = mysqli_fetch_array($resultado)) { ?>  
                <tr>
                  <td>
                    <a class="delete" href="../del/delturno.php?id=<?php echo $row['turnoid']?>" onclick="return confirmar('¿Está seguro que desea eliminar el registro?')">
                        <i class="material-icons tiny delete">delete_forever</i>BORRAR </a></td>

                  <td><?php echo $row['turnofecha']?></td>
                  <td><?php echo $row['turnohora']?></td>
                  <td><?php 
                      $consulta="SELECT * FROM ssm_doctor WHERE doctorid = '".$row['turnomedico']."'";
                      $resultado2 = mysqli_query($conectar, $consulta);
                      if ($resultado2){
                        while ($row2 = mysqli_fetch_array($resultado2)) {
                          echo $row2['doctornombres'];
                        }
                      }
                      ?></td> 
                  <td><?php 
                      $consulta="SELECT * FROM ssm_paciente WHERE pacienteuser = '".$row['turnopaciente']."'";
                      $resultado2 = mysqli_query($conectar, $consulta);
                      if ($resultado2){
                        while ($row2 = mysqli_fetch_array($resultado2)) {
                          echo $row2['pacientenombres'];
                        }
                      }
                      ?></td> 
                </tr>
          <?php  
          }}
          ?>
      </tbody>
  </table>
</div>
<?php }?>


<?php if ($_SESSION['login_user']=="Medico"){ ?>
  <div class="container">
    <div class="row">
        <div class="col m12 s12 ">
            <h4 class="form_title center colver">Lista de turnos diarios</h4>
        </div>    
    </div>

  <table class="highlight centered responsive-table">
      <thead>
      <tr>
          <th>Acción</th>
          <th>Fecha</th>
          <th>Hora</th>
          <th>Paciente</th>
      </tr>
      </thead>

      <tbody>
          <?php
          $id = $_SESSION['login_id'];
          $query = "SELECT * FROM ssm_turnos WHERE turnomedico = $id AND turnofecha = CURDATE() ORDER BY turnofecha ASC";
            $resultado = mysqli_query($conectar, $query);
            if ($resultado){
              while ($row = mysqli_fetch_array($resultado)) { ?>  
                <tr>
                  <td>
                    <a class="delete" href="../del/delturno.php?id=<?php echo $row['turnoid']?>" onclick="return confirmar('¿Está seguro que desea eliminar el registro?')">
                        <i class="material-icons tiny delete">delete_forever</i>BORRAR </a></td>

                  <td><?php echo $row['turnofecha']?></td>
                  <td><?php echo $row['turnohora']?></td> 
                  <td><?php 
                      $consulta="SELECT * FROM ssm_paciente WHERE pacienteuser = '".$row['turnopaciente']."'";
                      $resultado2 = mysqli_query($conectar, $consulta);
                      if ($resultado2){
                        while ($row2 = mysqli_fetch_array($resultado2)) {
                          echo $row2['pacientenombres'];
                        }
                      }
                      ?></td> 
                </tr>
          <?php  
          }}
          ?>
      </tbody>
  </table>
</div>
<?php }?>



  </main>
  <div class="container">
    <div class="progress"> <div class="determinate teal lighten-4" style="width: 100%"></div></div>
    <div class="progress"> <div class="determinate teal lighten-2" style="width: 100%"></div></div>
    <div class="progress"> <div class="determinate teal" style="width: 100%"></div></div>
  </div>
  <footer class="page-footer container">
  </footer>

  <script type="text/javascript" src="../assets/js/materialize.js"></script>
  <script type="text/javascript" src="../assets/js/main.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      M.AutoInit();
    });
  </script> 
  <script type="text/javascript">
    function valida_cedula() {
      var cad = document.getElementById("cedula").value.trim();
      var total = 0;
      var longitud = cad.length;
      var longcheck = longitud - 1;
      if (cad !== "" && longitud === 10){
        for(i = 0; i < longcheck; i++){
          if (i%2 === 0) {
            var aux = cad.charAt(i) * 2;
            if (aux > 9) aux -= 9;
            total += aux;
          } else {
            total += parseInt(cad.charAt(i)); // parseInt o concatenará en lugar de sumar
          }
        }
        total = total % 10 ? 10 - total % 10 : 0;
        if (cad.charAt(longitud-1) != total) {
          document.getElementById("cedula").value = ("0");
        }
      }
    }
  </script>
  <script>
    function confirmar ( mensaje ) {
      return confirm( mensaje );
    }
  </script>
</body>
</html>