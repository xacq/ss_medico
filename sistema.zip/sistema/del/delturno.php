<?php
    require_once("../config/verificacion.php");
    mysqli_report(MYSQLI_REPORT_ERROR);
    require_once("../config/link.php");
    if (isset($_GET['id'])){
        $id = $_GET['id'];
        $sql_pac = "SELECT ssmtur_paciente FROM ssmturnos WHERE ssmtur_id = $id";
        $result_pac = mysqli_query($conectar, $sql_pac);
        $row_pac = mysqli_fetch_array($result_pac);
        $paciente = $row_pac['ssmtur_paciente'];
        $sql_pac = "UPDATE ssmpacientes SET ssmpac_estado = '1' WHERE ssmpac_id = $paciente";
        $result_pac = mysqli_query($conectar, $sql_pac);

        $consulta2 = "DELETE FROM ssmturnos WHERE ssmtur_id = $id";
        $result2 = mysqli_query($conectar,$consulta2);
        if($result2){
            echo '<script>alert("TURNO ELIMINADO CORRECTAMENTE.")</script>';
            echo '<script>window.location="../3.medicogeneral.php"</script>';
        }
        else{
            echo '<script>alert("OOPS...! HUBO UN ERROR AL ELIMINAR EL REGISTRO.")</script>';
            echo '<script>window.location="../3.medicogeneral.php"</script>';
        }
    }
?>