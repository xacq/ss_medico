<?php
    require_once("../config/verificacion.php");
    require_once("../config/link.php");
    if (isset($_GET['id'])){
        $id = $_GET['id'];

        $sql_paciente = "DELETE FROM ssm_paciente WHERE pacienteuser = $id";
        $code_result = mysqli_query($conectar,$sql_paciente);

        if($code_result){
            echo '<script>alert("REGISTRO ELIMINADO CORRECTAMENTE")</script>';
            echo '<script>window.location="../lists/1.listpaciente.php"</script>';
        }
        else{
            echo '<script>alert("OOPS...! HUBO UN ERROR AL ELIMINAR EL REGISTRO.")</script>';
            echo '<script>window.location="../lists/1.listpaciente.php"</script>';
        }
    }
?>